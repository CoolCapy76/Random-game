package com.example.randomgame

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lateinit var closeApplicationBtn: Button
        setContentView(R.layout.activity_main)

        val buttonSecondActivity = findViewById<Button>(R.id.button1)
        buttonSecondActivity.setOnClickListener {
            val secondActivityIntent = Intent(
                applicationContext, SecondActivity2::class.java
            )
            startActivity(secondActivityIntent)
        }

        val activity: MainActivity = MainActivity()
        closeApplicationBtn = findViewById(R.id.btn2)
        closeApplicationBtn.setOnClickListener {
            activity.finish()
            System.exit(0)
        }
    }
}
