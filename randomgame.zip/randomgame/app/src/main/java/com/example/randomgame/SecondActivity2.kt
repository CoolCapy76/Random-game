package com.example.randomgame

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import kotlin.random.Random

class SecondActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second2)

        val button = findViewById<Button>(R.id.btn1)
        val mintext = findViewById<EditText>(R.id.min)
        val maxtext = findViewById<EditText>(R.id.max)
        val resultText = findViewById<TextView>(R.id.res)
        var min = 0
        var max = 0
        val errmsg = "Min is bigger than max"

        button.setOnClickListener {
            min = mintext.text.toString().toInt()
            max = maxtext.text.toString().toInt()

            if (min > max) {
                resultText.text = errmsg
            } else {
                val randomInt = Random.nextInt(min, max + 1)
                resultText.text = randomInt.toString()
            }
        }

        val buttonMainActivity = findViewById<Button>(R.id.btn2)
        buttonMainActivity.setOnClickListener {
            val mainActivityIntent = Intent(this@SecondActivity2, MainActivity::class.java)
            startActivity(mainActivityIntent)
        }
    }
}
